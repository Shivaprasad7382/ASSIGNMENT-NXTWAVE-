# CloudSuite Persona-Adaptive Customer Support Agent

A command-line (and bonus Streamlit) customer support agent that detects the
persona of an incoming customer message, retrieves grounded answers from a
knowledge base using Retrieval-Augmented Generation (RAG), adapts its tone to
the detected persona, and escalates to a human agent — with a structured
handoff summary — whenever the issue is outside what automation should
safely resolve.

## 1. Project Overview

The agent simulates first-line support for **CloudSuite**, a fictional SaaS
product. It classifies every incoming message into one of three personas
(Technical Expert, Frustrated User, Business Executive), retrieves the most
relevant chunks from an 11-document knowledge base, and asks Claude to
generate a response **grounded only in those retrieved chunks** — in a tone
appropriate to the persona. If retrieval confidence is low, the topic is
account-sensitive (billing/security/legal), or the user remains
dissatisfied, the agent escalates and produces a structured JSON handoff
summary for a human agent instead of generating an answer.

## 2. Tech Stack

| Component            | Choice                                   | Version       |
|-----------------------|-------------------------------------------|---------------|
| Language               | Python                                     | 3.11+         |
| LLM                    | Anthropic Claude (`claude-sonnet-4-6`)     | via `anthropic` SDK 0.40.0 |
| Embeddings             | scikit-learn `TfidfVectorizer`             | scikit-learn ≥1.4 |
| Vector Database        | FAISS (`IndexFlatIP`, cosine via normalized inner product) | faiss-cpu 1.14.3 |
| PDF parsing            | pypdf                                      | ≥4.0          |
| PDF generation (KB)    | reportlab                                  | ≥4.0          |
| UI                     | CLI (required) + Streamlit (bonus)         | streamlit ≥1.32 |

**Why TF-IDF instead of a neural embedding model?** It requires no model
download, no GPU, and is fully deterministic — ideal for a small, fixed,
vocabulary-rich support knowledge base where exact keyword/phrase overlap
(e.g. "401 Unauthorized", "API key") is a strong relevance signal. The
`RAGPipeline.retrieve()` interface is embedding-agnostic, so swapping in
`sentence-transformers` or an API embedding model later is a localized
change (see `src/rag.py`).

## 3. Architecture

```
                 ┌─────────────────┐
   User Query →  │ Persona Detection │  (rule-based keyword scoring,
                 └─────────┬────────┘    LLM fallback if ambiguous)
                            │
                            ▼
                 ┌─────────────────┐
                 │   Retrieval (RAG) │  (TF-IDF embeddings → FAISS
                 └─────────┬────────┘   top-k similarity search)
                            │
                            ▼
                 ┌─────────────────┐
                 │ Escalation Check  │  (low confidence / sensitive
                 └────┬─────────┬───┘   topic / repeat turns / no match)
                      │         │
            escalate? │         │ no
                  yes  │         │
                      ▼         ▼
          ┌────────────────┐  ┌──────────────────────┐
          │ Human Handoff   │  │ Response Generation    │
          │ Summary (JSON)  │  │ (persona-styled, Claude,│
          └────────────────┘  │  grounded in retrieved   │
                               │  chunks only)            │
                               └──────────────────────┘
```

This matches `SupportAgent.handle_message()` in `src/agent.py`, which runs
the five stages in order for every turn.

## 4. Persona Detection Strategy

**Classification method:** hybrid rule-based + LLM fallback
(`src/persona.py`).

1. A keyword/heuristic scorer counts matches against three curated keyword
   lists (technical terms, frustration/urgency language, business-impact
   language), plus signals like exclamation-mark density and ALL-CAPS
   tokens (frustration) or short outcome-oriented phrasing (executive).
2. The persona with the highest score is chosen, with a confidence score
   equal to that persona's share of total signal hits.
3. If confidence is below `0.34` (the signal is ambiguous or near-empty),
   the agent falls back to a single Claude classification call
   (`LLMClient.classify_persona`) constrained to the three valid labels.

**Why hybrid?** Keyword scoring is free, instant, and fully explainable
(important for support tooling audits), and resolves the large majority of
real messages correctly. The LLM fallback only fires on genuinely ambiguous
input, keeping latency and cost low without sacrificing accuracy on edge
cases.

## 5. RAG Pipeline Design

**Chunking strategy** (`src/loader.py`): Markdown/TXT/PDF documents are
authored with `## Section: <name>` headers; the loader splits on these
headers so each chunk is one coherent topic with rich metadata (`source`
file name + `section` name, or `page N` for PDFs). Documents without
section headers fall back to 2-paragraph chunking. This keeps chunks
self-contained and avoids splitting a procedure or policy mid-thought.

**Embedding model:** TF-IDF (unigrams + bigrams, English stop words
removed, 4096 max features), L2-normalized.

**Vector database:** FAISS `IndexFlatIP` (exact inner-product search over
normalized vectors = cosine similarity). Exact search is appropriate at
this corpus size (tens of chunks); swapping to an approximate index (e.g.
`IndexIVFFlat`) is a one-line change if the KB grows large.

**Retrieval strategy:** top-`k` (default 4) chunks per query, returned with
their similarity score. The top score also feeds directly into the
escalation confidence check (see below).

## 6. Escalation Logic

Implemented in `src/escalation.py`, fully configurable via
`EscalationConfig`:

| Trigger | Default threshold | Configurable field |
|---|---|---|
| No chunks retrieved at all | top score `<= 0` | n/a |
| Low retrieval confidence | top score `< 0.12` | `min_confidence` |
| Account-sensitive keyword (billing fraud, legal, security/GDPR) | exact word-boundary match against a curated list | `sensitive_keywords` |
| User signals continued dissatisfaction (e.g. "still not working") | phrase match | `dissatisfaction_phrases` |
| Conversation has run too many turns without resolution | `turn_count >= 3` | `max_repeat_turns` |

Sensitive-keyword matching uses word-boundary regex (not substring match)
to avoid false positives such as "**issue**" incorrectly matching "**sue**".

When any trigger fires, the agent **does not** call the response-generation
LLM step — it goes straight to building a `HandoffSummary`
(`src/handoff.py`) instead, guaranteeing escalations never receive a
possibly-wrong automated answer.

## 7. Setup Instructions

```bash
# 1. Clone the repo and enter it
git clone <your-repo-url> support-agent
cd support-agent

# 2. Create and activate a virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set your Anthropic API key
cp .env.example .env
# edit .env and paste your key, then:
export ANTHROPIC_API_KEY=sk-ant-...   # or `export $(cat .env | xargs)` on Linux/macOS

# 5. Run the CLI
python src/cli.py

# Bonus: run the Streamlit UI instead
streamlit run src/app_streamlit.py
```

## 8. Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | Yes | Anthropic API key used for persona-fallback classification and grounded response generation (`claude-sonnet-4-6`). |

No API key is ever committed to the repository — `.env` is git-ignored and
only `.env.example` (a placeholder) is tracked.

## 9. Example Queries

Try these in the CLI to see all three personas, grounded answers, and an
escalation:

1. `Can you explain the API authentication failure and provide error details?`
   → **Technical Expert** persona, grounded in `03_api_authentication.md`.
2. `I've tried everything and nothing works, my password reset link keeps expiring!`
   → **Frustrated User** persona, empathetic tone, grounded in `01_password_reset.md`.
3. `How does this billing outage impact our operations and when will it be resolved?`
   → **Business Executive** persona, concise impact-focused answer.
4. `My account may have been hacked and someone made an unauthorized charge.`
   → Escalates immediately (account-sensitive: security + billing fraud) with a JSON handoff summary.
5. `Still not working after your last suggestion, this is the third time I'm asking.`
   → Escalates due to repeated dissatisfaction signal.

## 10. Known Limitations & Future Improvements

- **TF-IDF retrieval** is purely lexical; it will miss semantically similar
  phrasing that shares no vocabulary with the source documents (e.g.
  "can't log in" vs. "authentication failure"). A neural embedding model
  (sentence-transformers / Voyage / OpenAI embeddings) would improve recall
  at the cost of an external dependency.
- **Persona detection** is single-label per message; a message can
  realistically blend personas (e.g. an angry executive). The current
  design returns the single best match plus its confidence rather than a
  full distribution.
- **No persistent storage**: conversation history lives only in memory for
  the current process run; a production system would persist sessions
  (e.g. SQLite/Postgres) per the optional storage layer noted in the spec.
- **Single-turn escalation memory**: "repeat turns" is a simple counter
  rather than true issue-thread tracking across disconnected sessions.
- **No confidence-calibrated thresholds**: the `min_confidence = 0.12`
  cutoff was tuned by inspection on this knowledge base; a larger,
  real-world KB would need re-calibration (or a learned threshold).

## Repository Structure

```
support-agent/
├── data/                          # Knowledge base (10 .md + 1 .pdf)
├── src/
│   ├── loader.py                  # Document loading & chunking
│   ├── rag.py                     # TF-IDF + FAISS retrieval pipeline
│   ├── persona.py                 # Persona detection (rules + LLM fallback)
│   ├── escalation.py              # Escalation trigger logic
│   ├── handoff.py                 # Structured handoff summary builder
│   ├── llm_client.py              # Anthropic Claude API wrapper
│   ├── agent.py                   # Orchestrator (SupportAgent)
│   ├── cli.py                     # Required CLI interface
│   └── app_streamlit.py           # Bonus Streamlit chat UI
├── requirements.txt
├── .env.example
└── README.md
```
