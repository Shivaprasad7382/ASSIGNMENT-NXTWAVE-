"""
Bonus Streamlit chat UI for the Persona-Adaptive Customer Support Agent.

Run with:
    export ANTHROPIC_API_KEY=sk-ant-...
    streamlit run src/app_streamlit.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import streamlit as st
from agent import SupportAgent

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

st.set_page_config(page_title="CloudSuite Support Agent", page_icon="🛠️", layout="wide")
st.title("🛠️ CloudSuite Persona-Adaptive Support Agent")

if "agent" not in st.session_state:
    try:
        st.session_state.agent = SupportAgent(data_dir=DATA_DIR)
        st.session_state.chat = []
    except RuntimeError as e:
        st.error(str(e))
        st.stop()

for turn in st.session_state.chat:
    with st.chat_message(turn["role"]):
        st.markdown(turn["content"])
        if turn.get("meta"):
            st.caption(turn["meta"])

user_input = st.chat_input("Describe your issue...")

if user_input:
    st.session_state.chat.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    result = st.session_state.agent.handle_message(user_input)

    persona_line = f"**Persona:** {result.persona.persona} (confidence={result.persona.confidence})"
    sources = ", ".join(f"{r.chunk.source} [{r.chunk.section}]" for r in result.retrieved) or "none"

    with st.chat_message("assistant"):
        st.markdown(f"_{persona_line}_")
        st.caption(f"Retrieved sources: {sources}")
        if result.escalation.escalate:
            st.warning(f"🚨 Escalated to a human agent — {result.escalation.reason}")
            st.markdown("**Human handoff summary:**")
            st.code(result.handoff.to_json(), language="json")
            content = f"Escalated: {result.escalation.reason}"
        else:
            st.markdown(result.response)
            content = result.response

    st.session_state.chat.append({
        "role": "assistant",
        "content": content,
        "meta": f"{persona_line} | sources: {sources}",
    })
