"""
Retrieval-Augmented Generation pipeline.

Embedding model: scikit-learn TF-IDF vectorizer (chosen for zero external
network/model-download dependency, deterministic behavior, and good
precision on short, vocabulary-rich support documents). The TF-IDF vectors
are L2-normalized and stored in a FAISS index using inner-product search,
which is mathematically equivalent to cosine similarity search over
normalized vectors.

Swappable: the embedding step could be pointed at sentence-transformers or
an API-based embedding model without changing the retrieval interface
(retrieve() always returns RetrievedChunk objects with a similarity score).
"""
from dataclasses import dataclass
from typing import List

import numpy as np
import faiss
from sklearn.feature_extraction.text import TfidfVectorizer

from loader import Chunk


@dataclass
class RetrievedChunk:
    chunk: Chunk
    score: float


class RAGPipeline:
    def __init__(self, chunks: List[Chunk]):
        self.chunks = chunks
        self.vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_features=4096,
        )
        corpus = [c.text for c in chunks]
        matrix = self.vectorizer.fit_transform(corpus).toarray().astype("float32")
        norms = np.linalg.norm(matrix, axis=1, keepdims=True)
        norms[norms == 0] = 1e-9
        matrix = matrix / norms
        self.dim = matrix.shape[1]

        self.index = faiss.IndexFlatIP(self.dim)
        self.index.add(matrix)

    def retrieve(self, query: str, top_k: int = 4) -> List[RetrievedChunk]:
        q_vec = self.vectorizer.transform([query]).toarray().astype("float32")
        norm = np.linalg.norm(q_vec, axis=1, keepdims=True)
        norm[norm == 0] = 1e-9
        q_vec = q_vec / norm

        scores, idxs = self.index.search(q_vec, top_k)
        results = []
        for score, idx in zip(scores[0], idxs[0]):
            if idx == -1:
                continue
            results.append(RetrievedChunk(chunk=self.chunks[idx], score=float(score)))
        return results
