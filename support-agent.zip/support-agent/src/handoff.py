"""
Structured human handoff summary, produced whenever escalation triggers.
"""
import json
from dataclasses import dataclass, asdict
from typing import List, Dict


@dataclass
class HandoffSummary:
    persona: str
    issue: str
    conversation_history: List[Dict[str, str]]
    documents_used: List[str]
    attempted_steps: List[str]
    recommendation: str
    escalation_reason: str

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)


def build_handoff_summary(persona: str, history: List[Dict[str, str]],
                           documents_used: List[str], escalation_reason: str) -> HandoffSummary:
    user_turns = [t["content"] for t in history if t["role"] == "user"]
    issue = user_turns[0] if user_turns else "Unspecified issue"

    attempted_steps = []
    for t in history:
        if t["role"] == "assistant":
            first_line = t["content"].strip().split("\n")[0]
            attempted_steps.append(first_line[:120])

    if "account-sensitive" in escalation_reason.lower():
        recommendation = "Verify customer identity and route to the appropriate specialized team (security/billing/legal)."
    elif "no relevant information" in escalation_reason.lower() or "confidence too low" in escalation_reason.lower():
        recommendation = "Knowledge base has no confident answer; have a human agent investigate directly."
    elif "unresolved" in escalation_reason.lower() or "turns" in escalation_reason.lower():
        recommendation = "Customer has not been satisfied by automated troubleshooting; prioritize for direct human follow-up."
    else:
        recommendation = "Review conversation and continue support manually."

    return HandoffSummary(
        persona=persona,
        issue=issue,
        conversation_history=history,
        documents_used=sorted(set(documents_used)),
        attempted_steps=attempted_steps,
        recommendation=recommendation,
        escalation_reason=escalation_reason,
    )
