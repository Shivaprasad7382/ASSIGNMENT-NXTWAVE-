"""
Thin wrapper around the Anthropic Claude API used for:
  1. Persona classification fallback (low-confidence rule-based cases).
  2. Grounded, persona-adapted response generation from retrieved chunks.

Requires the ANTHROPIC_API_KEY environment variable to be set.
"""
import os
from typing import List

import anthropic

from persona import PERSONAS
from rag import RetrievedChunk

MODEL = "claude-sonnet-4-6"


class LLMClient:
    def __init__(self, api_key: str = None, model: str = MODEL):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Export it before running the agent, "
                "e.g. `export ANTHROPIC_API_KEY=sk-ant-...`"
            )
        self.client = anthropic.Anthropic(api_key=self.api_key)
        self.model = model

    def classify_persona(self, message: str) -> str:
        prompt = (
            "Classify the customer support message below into exactly one of these "
            f"personas: {', '.join(PERSONAS)}.\n\n"
            f"Message: \"{message}\"\n\n"
            "Reply with ONLY the persona label, nothing else."
        )
        resp = self.client.messages.create(
            model=self.model,
            max_tokens=20,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(b.text for b in resp.content if b.type == "text").strip()
        return text

    def generate_response(self, persona: str, user_message: str,
                           retrieved: List[RetrievedChunk],
                           history: List[dict]) -> str:
        context_block = "\n\n".join(
            f"[Source: {r.chunk.source} | {r.chunk.section}]\n{r.chunk.text}"
            for r in retrieved
        ) or "No relevant documents were retrieved."

        style_guides = {
            "Technical Expert": (
                "Write a detailed, technical response. Include root-cause analysis "
                "where the context supports it, and step-by-step troubleshooting "
                "instructions. Technical jargon is fine."
            ),
            "Frustrated User": (
                "Write an empathetic, reassuring response in simple, plain language. "
                "Acknowledge the frustration briefly, then give clear, action-oriented "
                "next steps. Avoid technical jargon."
            ),
            "Business Executive": (
                "Write a concise, impact-focused response. Lead with the business "
                "impact and an estimated resolution timeline if the context supports "
                "one. Minimize technical jargon. Keep it short."
            ),
        }
        style_guide = style_guides.get(persona, style_guides["Technical Expert"])

        system_prompt = (
            "You are a customer support agent for CloudSuite, a SaaS product. "
            "You must answer ONLY using the provided context below. "
            "If the context does not contain the answer, say clearly that you "
            "don't have that information rather than guessing or inventing details. "
            "Never fabricate policy numbers, error codes, or steps that are not in "
            "the context.\n\n"
            f"Persona-specific style instructions: {style_guide}\n\n"
            f"--- CONTEXT ---\n{context_block}\n--- END CONTEXT ---"
        )

        messages = []
        for turn in history[-6:]:
            messages.append({"role": turn["role"], "content": turn["content"]})
        messages.append({"role": "user", "content": user_message})

        resp = self.client.messages.create(
            model=self.model,
            max_tokens=600,
            system=system_prompt,
            messages=messages,
        )
        return "".join(b.text for b in resp.content if b.type == "text").strip()
