"""
Persona detection.

Strategy: a hybrid of lightweight rule/keyword scoring (fast, deterministic,
explainable, zero cost) followed by an optional LLM-based classification
call as a fallback/refinement when the rule-based signal is weak or
ambiguous. This mirrors how production systems often blend cheap heuristics
with an LLM for edge cases rather than calling the LLM for every message.
"""
import re
from dataclasses import dataclass
from typing import Dict

PERSONAS = ["Technical Expert", "Frustrated User", "Business Executive"]

_TECHNICAL_KEYWORDS = [
    "api", "log", "logs", "endpoint", "token", "auth", "authentication",
    "config", "configuration", "stack trace", "error code", "http",
    "status code", "webhook", "json", "payload", "header", "sdk",
    "rate limit", "latency", "debug", "exception", "oauth", "ssl", "tls",
    "database", "query", "schema", "request id", "console", "cli",
]
_FRUSTRATED_KEYWORDS = [
    "frustrated", "angry", "annoyed", "ridiculous", "unacceptable",
    "still not working", "nothing works", "tried everything", "again",
    "third time", "fed up", "terrible", "worst", "useless", "asap",
    "immediately", "urgent", "please help", "disappointed", "furious",
]
_EXECUTIVE_KEYWORDS = [
    "business impact", "operations", "revenue", "sla", "downtime cost",
    "stakeholders", "leadership", "board", "contract", "renewal",
    "when will this be resolved", "bottom line", "executive", "client",
    "customers are affected", "reputation", "briefly",
]


@dataclass
class PersonaResult:
    persona: str
    confidence: float
    signals: Dict[str, int]


def _score_keywords(text_lower: str, keywords) -> int:
    return sum(1 for kw in keywords if kw in text_lower)


def detect_persona_rule_based(message: str) -> PersonaResult:
    text_lower = message.lower()

    scores = {
        "Technical Expert": _score_keywords(text_lower, _TECHNICAL_KEYWORDS),
        "Frustrated User": _score_keywords(text_lower, _FRUSTRATED_KEYWORDS),
        "Business Executive": _score_keywords(text_lower, _EXECUTIVE_KEYWORDS),
    }

    if message.count("!") >= 2:
        scores["Frustrated User"] += 2
    if len(re.findall(r"\b[A-Z]{4,}\b", message)) >= 1:
        scores["Frustrated User"] += 1  # ALL-CAPS shouting
    if len(message.split()) <= 18 and ("impact" in text_lower or "when" in text_lower):
        scores["Business Executive"] += 1

    best_persona = max(scores, key=scores.get)
    best_score = scores[best_persona]
    total = sum(scores.values()) or 1
    confidence = best_score / total if best_score > 0 else 0.0

    if best_score == 0:
        best_persona = "Technical Expert"
        confidence = 0.0

    return PersonaResult(persona=best_persona, confidence=round(confidence, 2), signals=scores)


def detect_persona_llm(message: str, llm_client) -> PersonaResult:
    """LLM-based refinement, used when rule-based confidence is low.
    llm_client must expose a `.classify_persona(message)` method returning
    one of PERSONAS as a string.
    """
    persona = llm_client.classify_persona(message)
    if persona not in PERSONAS:
        persona = "Technical Expert"
    return PersonaResult(persona=persona, confidence=0.6, signals={})


def detect_persona(message: str, llm_client=None, confidence_threshold: float = 0.34) -> PersonaResult:
    rule_result = detect_persona_rule_based(message)
    if rule_result.confidence >= confidence_threshold or llm_client is None:
        return rule_result
    try:
        return detect_persona_llm(message, llm_client)
    except Exception:
        return rule_result
