"""
Agent orchestrator: wires together persona detection -> retrieval ->
response generation -> escalation check -> human handoff.

Pipeline per turn:
  User Query
    -> Persona Detection
    -> Retrieval (RAG)
    -> Escalation Check (uses retrieval confidence + message content + turn count)
    -> Response Generation (only if NOT escalating) OR Handoff Summary (if escalating)
"""
from dataclasses import dataclass, field
from typing import List, Dict, Optional

from loader import load_knowledge_base
from rag import RAGPipeline, RetrievedChunk
from persona import detect_persona, PersonaResult
from escalation import check_escalation, EscalationConfig, EscalationDecision
from handoff import build_handoff_summary, HandoffSummary
from llm_client import LLMClient


@dataclass
class TurnResult:
    user_message: str
    persona: PersonaResult
    retrieved: List[RetrievedChunk]
    escalation: EscalationDecision
    response: Optional[str]
    handoff: Optional[HandoffSummary]


class SupportAgent:
    def __init__(self, data_dir: str, escalation_config: EscalationConfig = None,
                 use_llm_persona_fallback: bool = True):
        chunks = load_knowledge_base(data_dir)
        if not chunks:
            raise RuntimeError(f"No knowledge base documents found in {data_dir}")
        self.rag = RAGPipeline(chunks)
        self.escalation_config = escalation_config or EscalationConfig()
        self.llm = LLMClient()
        self.use_llm_persona_fallback = use_llm_persona_fallback

        self.history: List[Dict[str, str]] = []   # role/content turns for the LLM
        self.documents_used: List[str] = []
        self.turn_count = 0

    def handle_message(self, message: str, top_k: int = 4) -> TurnResult:
        self.turn_count += 1

        persona_result = detect_persona(
            message,
            llm_client=self.llm if self.use_llm_persona_fallback else None,
        )

        retrieved = self.rag.retrieve(message, top_k=top_k)
        top_score = retrieved[0].score if retrieved else 0.0

        escalation_decision = check_escalation(
            message=message,
            top_score=top_score,
            turn_count=self.turn_count,
            config=self.escalation_config,
        )

        self.history.append({"role": "user", "content": message})

        if escalation_decision.escalate:
            handoff = build_handoff_summary(
                persona=persona_result.persona,
                history=self.history,
                documents_used=self.documents_used,
                escalation_reason=escalation_decision.reason,
            )
            return TurnResult(
                user_message=message,
                persona=persona_result,
                retrieved=retrieved,
                escalation=escalation_decision,
                response=None,
                handoff=handoff,
            )

        response_text = self.llm.generate_response(
            persona=persona_result.persona,
            user_message=message,
            retrieved=retrieved,
            history=self.history,
        )
        self.history.append({"role": "assistant", "content": response_text})
        self.documents_used.extend(r.chunk.source for r in retrieved)

        return TurnResult(
            user_message=message,
            persona=persona_result,
            retrieved=retrieved,
            escalation=escalation_decision,
            response=response_text,
            handoff=None,
        )
