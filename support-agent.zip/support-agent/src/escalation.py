"""
Escalation logic.

Escalation triggers (all configurable via EscalationConfig):
  1. No relevant chunks retrieved at all.
  2. Best retrieval similarity score below `min_confidence`.
  3. Message matches an account-sensitive keyword (billing/legal/security).
  4. The user's message signals continued dissatisfaction after a prior
     agent turn (e.g. "still not working", "that didn't help").
  5. The same user has now reached >= `max_repeat_turns` turns on this
     conversation without resolution.
"""
import re
from dataclasses import dataclass, field
from typing import List, Optional


_SENSITIVE_KEYWORDS = [
    "legal", "lawsuit", "subpoena", "sue", "gdpr", "delete my data",
    "data breach", "compromised", "hacked", "fraud", "fraudulent charge",
    "chargeback", "unauthorized charge", "compliance", "regulator",
    "account takeover", "stolen", "lawyer", "attorney",
]

_DISSATISFACTION_PHRASES = [
    "still not working", "still doesn't work", "didn't help", "did not help",
    "not resolved", "same issue", "tried that already", "already tried",
    "still broken", "no luck", "still having", "doesn't fix",
]


@dataclass
class EscalationConfig:
    min_confidence: float = 0.12           # below this top retrieval score -> escalate
    max_repeat_turns: int = 3               # user turns on the same issue -> escalate
    sensitive_keywords: List[str] = field(default_factory=lambda: list(_SENSITIVE_KEYWORDS))
    dissatisfaction_phrases: List[str] = field(default_factory=lambda: list(_DISSATISFACTION_PHRASES))


@dataclass
class EscalationDecision:
    escalate: bool
    reason: Optional[str]


def check_escalation(message: str, top_score: float, turn_count: int,
                      config: EscalationConfig) -> EscalationDecision:
    text_lower = message.lower()

    for kw in config.sensitive_keywords:
        pattern = r"\b" + re.escape(kw) + r"\b"
        if re.search(pattern, text_lower):
            return EscalationDecision(True, f"Account-sensitive topic detected ('{kw}') — requires human verification.")

    if top_score <= 0.0:
        return EscalationDecision(True, "No relevant information found in the knowledge base.")

    if top_score < config.min_confidence:
        return EscalationDecision(True, f"Retrieval confidence too low ({top_score:.2f} < {config.min_confidence}).")

    for phrase in config.dissatisfaction_phrases:
        if phrase in text_lower:
            return EscalationDecision(True, "User indicates the issue remains unresolved after a prior attempt.")

    if turn_count >= config.max_repeat_turns:
        return EscalationDecision(True, f"User has reached {turn_count} turns on this issue without resolution.")

    return EscalationDecision(False, None)
