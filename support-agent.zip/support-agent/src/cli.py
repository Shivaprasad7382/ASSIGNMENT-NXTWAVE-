"""
Interactive command-line chatbot for the Persona-Adaptive Customer Support Agent.

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python src/cli.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from agent import SupportAgent

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

BANNER = """
==============================================================
  CloudSuite Persona-Adaptive Customer Support Agent (CLI)
==============================================================
Type your support question below. Type 'exit' or 'quit' to stop.
"""


def divider():
    print("-" * 62)


def main():
    print(BANNER)
    print(f"Loading knowledge base from: {DATA_DIR}")
    try:
        agent = SupportAgent(data_dir=DATA_DIR)
    except RuntimeError as e:
        print(f"\n[ERROR] {e}")
        sys.exit(1)
    print(f"Knowledge base loaded: {len(agent.rag.chunks)} chunks indexed.\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit"):
            print("Goodbye!")
            break

        result = agent.handle_message(user_input)

        divider()
        print(f"Detected Persona : {result.persona.persona}  "
              f"(confidence={result.persona.confidence})")

        sources = [f"{r.chunk.source} ({r.chunk.section}) score={r.score:.2f}" for r in result.retrieved]
        print(f"Retrieved Sources: {sources if sources else 'none'}")

        if result.escalation.escalate:
            print(f"Escalation       : YES — {result.escalation.reason}")
            divider()
            print("Agent: I'm escalating this to a human support representative "
                  "so it gets the right attention. Here is the handoff summary:\n")
            print(result.handoff.to_json())
        else:
            print("Escalation       : NO")
            divider()
            print(f"Agent: {result.response}")
        divider()
        print()


if __name__ == "__main__":
    main()
