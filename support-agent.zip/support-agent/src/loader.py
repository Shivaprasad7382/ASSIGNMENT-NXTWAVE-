"""
Document loading and chunking for the knowledge base.

Supports .md, .txt, and .pdf files. Each chunk carries metadata about its
source document and section, which is later surfaced to the user as a
citation and recorded in the escalation handoff summary.
"""
import os
import re
from dataclasses import dataclass, field
from typing import List

from pypdf import PdfReader


@dataclass
class Chunk:
    text: str
    source: str           # file name
    section: str           # section / page label
    chunk_id: str = field(default="")


def _split_markdown_sections(text: str, source: str) -> List[Chunk]:
    """Split a markdown/txt document on '## Section:' headers when present,
    otherwise fall back to paragraph-based chunking."""
    chunks = []
    section_pattern = re.compile(r"^##\s*Section:\s*(.+)$", re.MULTILINE)
    matches = list(section_pattern.finditer(text))

    if matches:
        for i, m in enumerate(matches):
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            section_title = m.group(1).strip()
            body = text[start:end].strip()
            if body:
                chunks.append(Chunk(text=body, source=source, section=section_title))
    else:
        paras = [p.strip() for p in text.split("\n\n") if p.strip()]
        for i in range(0, len(paras), 2):
            body = "\n".join(paras[i:i + 2])
            chunks.append(Chunk(text=body, source=source, section=f"paragraph {i // 2 + 1}"))

    return chunks


def _load_pdf(path: str, source: str) -> List[Chunk]:
    chunks = []
    reader = PdfReader(path)
    for page_num, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        page_chunks = _split_markdown_sections(text, source)
        if page_chunks:
            for c in page_chunks:
                c.section = f"page {page_num} - {c.section}"
                chunks.append(c)
        elif text.strip():
            chunks.append(Chunk(text=text.strip(), source=source, section=f"page {page_num}"))
    return chunks


def load_knowledge_base(data_dir: str) -> List[Chunk]:
    """Load every supported document under data_dir and return a flat,
    chunked, metadata-tagged list ready for embedding."""
    all_chunks: List[Chunk] = []
    for fname in sorted(os.listdir(data_dir)):
        path = os.path.join(data_dir, fname)
        if not os.path.isfile(path):
            continue
        ext = fname.lower().rsplit(".", 1)[-1]

        if ext in ("md", "txt"):
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
            doc_chunks = _split_markdown_sections(text, fname)
        elif ext == "pdf":
            doc_chunks = _load_pdf(path, fname)
        elif ext == "docx":
            try:
                import docx  # python-docx
            except ImportError:
                continue
            d = docx.Document(path)
            text = "\n\n".join(p.text for p in d.paragraphs)
            doc_chunks = _split_markdown_sections(text, fname)
        else:
            continue

        for i, c in enumerate(doc_chunks):
            c.chunk_id = f"{fname}::{i}"
        all_chunks.extend(doc_chunks)

    return all_chunks
