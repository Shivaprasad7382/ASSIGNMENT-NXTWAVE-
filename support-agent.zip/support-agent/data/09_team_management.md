# Team & Permissions Management

## Section: Roles
CloudSuite supports four roles: Owner, Admin, Member, and Viewer. Only
Owners can transfer ownership or delete the workspace. Admins can manage
billing and invite/remove members.

## Section: Inviting Members
Invite new members from Settings > Team > Invite. Invitations expire after
7 days if not accepted. Professional plans support up to 25 members;
Enterprise is unlimited.

## Section: Removing a Member
Removing a member immediately revokes their access and reassigns their
unfinished tasks to the workspace Owner by default, configurable under
Settings > Team > Offboarding Rules.
