# Account Security

## Section: Two-Factor Authentication
2FA can be enabled under Settings > Security using an authenticator app
(TOTP) or SMS. Enterprise plans can enforce mandatory 2FA org-wide.

## Section: Suspicious Login Alerts
Logins from a new device or location trigger an email alert. Users can
review active sessions under Settings > Security > Active Sessions and
revoke any unrecognized session immediately.

## Section: Account Compromise
If you suspect your account has been compromised, immediately revoke all
active sessions, reset your password, and contact security@cloudsuite.io.
This is treated as a high-priority, account-sensitive issue requiring
escalation to the security team.
