# Performance Troubleshooting

## Section: Slow Dashboard Loading
Slow dashboard loads are most commonly caused by large datasets (>100k
records) rendered in a single view. Apply filters or use pagination to
improve load time. Clearing browser cache also resolves rendering issues
in roughly 30% of reported cases.

## Section: API Latency
Typical API p95 latency is under 300ms. Sustained latency above 1s should
be reported with a request ID (found in the `X-Request-ID` response header)
so engineering can trace the issue.

## Section: Bulk Import Timeouts
CSV imports above 20,000 rows via the UI may time out at the 5-minute
browser limit. Use the asynchronous Bulk Import API endpoint instead for
large datasets.
