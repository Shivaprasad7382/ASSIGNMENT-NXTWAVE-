# Common Integration Errors

## Section: Webhook Failures
Webhooks that fail to receive a 2xx response are retried 5 times with
exponential backoff (1m, 5m, 15m, 1h, 6h). After 5 failures the webhook is
automatically disabled and an alert email is sent to the workspace admin.

## Section: Slack Integration
If Slack notifications stop arriving, check that the CloudSuite Slack app
still has the `chat:write` scope under your Slack workspace's app settings;
Slack occasionally revokes scopes after workspace admin changes.

## Section: Zapier Sync Delay
Zapier polling integrations may show a sync delay of up to 15 minutes; this
is a Zapier platform limitation, not a CloudSuite issue.
