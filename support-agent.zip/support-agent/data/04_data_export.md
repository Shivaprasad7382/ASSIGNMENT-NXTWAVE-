# Data Export & Backups

## Section: Manual Export
Users can export workspace data as CSV or JSON from Settings > Data > Export.
Exports above 50,000 rows are processed asynchronously and emailed as a
download link valid for 72 hours.

## Section: Automated Backups
CloudSuite performs nightly automated backups retained for 30 days on all
plans, and 1 year on Enterprise. Backups are not user-downloadable; restoring
from a backup requires opening a support ticket.

## Section: GDPR Data Requests
EU customers can request a full data export or deletion under GDPR Article 15
and 17 by emailing privacy@cloudsuite.io. Requests are fulfilled within 30 days.
