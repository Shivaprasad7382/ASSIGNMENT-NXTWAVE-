# Password Reset Guide

## Section: Standard Reset
To reset your CloudSuite password:
1. Go to https://app.cloudsuite.io/login and click "Forgot Password".
2. Enter the email address associated with your account.
3. Check your inbox for a reset link (valid for 30 minutes).
4. Click the link and set a new password (minimum 10 characters, 1 number, 1 symbol).

## Section: Account Lockout
After 5 failed login attempts, accounts are locked for 15 minutes automatically.
If the lock persists beyond 15 minutes, the account may have been flagged for
suspicious activity and requires manual review by the security team.

## Section: SSO Users
If your organization uses Single Sign-On (SSO), password resets must be performed
through your identity provider (Okta, Azure AD, Google Workspace), not through
CloudSuite directly. Contact your IT administrator.
