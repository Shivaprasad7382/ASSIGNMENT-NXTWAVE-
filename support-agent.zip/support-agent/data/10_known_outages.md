# Known Outages & Status

## Section: Status Page
Real-time platform status is published at https://status.cloudsuite.io.
Subscribe to get email or SMS alerts for incidents affecting your region.

## Section: Recent Incident History
On record, past incidents have included regional API slowdowns and delayed
webhook delivery during peak traffic events. Root cause analyses (RCAs) for
incidents lasting over 1 hour are published within 5 business days on the
status page.
