# API Authentication Guide

## Section: API Key Generation
Generate an API key from Settings > Developer > API Keys. Keys are shown only
once at creation time; store them securely.

## Section: Authentication Errors
A 401 Unauthorized response typically means:
- The API key is missing from the `Authorization: Bearer <key>` header.
- The key has been revoked or expired (keys expire after 12 months by default).
- The request originates from an IP not on the account's allowlist, if IP
  allowlisting is enabled.

## Section: Rate Limiting
The API enforces 100 requests/minute per key on the Professional plan and
1000 requests/minute on Enterprise. Exceeding the limit returns HTTP 429 with
a `Retry-After` header indicating the wait time in seconds.

## Section: OAuth2 Flow
Enterprise customers can use OAuth2 client-credentials flow against
`https://auth.cloudsuite.io/oauth/token` for service-to-service authentication.
