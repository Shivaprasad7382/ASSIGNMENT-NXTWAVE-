# Billing FAQ

## Section: Subscription Plans
CloudSuite offers three plans: Starter ($19/mo), Professional ($49/mo), and
Enterprise (custom pricing). Annual billing receives a 15% discount.

## Section: Failed Payments
If a payment fails, we retry automatically after 3 days and again after 7 days.
After the second failed retry, the account is downgraded to read-only mode.
Update your payment method under Settings > Billing > Payment Methods.

## Section: Refunds
Refunds are issued for cancellations made within 14 days of initial purchase,
per our money-back guarantee. Refund requests after this window require manual
approval from the billing team and are evaluated case by case.

## Section: Invoices
Invoices are generated automatically on the billing date and emailed as PDF.
Past invoices can be downloaded from Settings > Billing > Invoice History.
