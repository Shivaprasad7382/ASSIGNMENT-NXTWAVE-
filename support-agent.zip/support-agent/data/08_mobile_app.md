# Mobile App Support

## Section: Push Notifications
Enable push notifications under the mobile app's Settings > Notifications.
If notifications stop working after an OS update, re-toggle the permission
in the device's system settings, as OS updates sometimes reset app
permissions.

## Section: Offline Mode
The mobile app caches the last 7 days of data for offline viewing. Changes
made offline sync automatically once connectivity is restored, with
conflict resolution favoring the most recent edit timestamp.
